import { useState } from "react";
import { useNavigate } from "react-router-dom";

interface FormFieldProps {
  label: string;
  placeholder: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}

const FormField: React.FC<FormFieldProps> = ({ label, placeholder, value, onChange, type = "text" }) => {
  return (
    <div className="flex w-full h-[87px] p-5 items-center gap-[-16px] rounded-[20px] bg-[#545FDF]">
      <div className="flex flex-col justify-center items-start gap-[3px] flex-1">
        <div className="text-[#E8DEF8] font-montserrat text-[20px] font-bold leading-[125%]">
          {label}
        </div>
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="text-[#E8DEF8] font-montserrat text-[15px] font-normal leading-[125%] bg-transparent border-none outline-none placeholder-[#E8DEF8] w-full"
        />
      </div>
    </div>
  );
};

const Logo = () => (
  <div className="flex w-[100px] h-[44px] justify-center items-center aspect-[25/11]">
    <div className="w-[100px] h-[44px] flex-shrink-0 relative">
      <div className="w-[100px] h-[44px] flex-shrink-0 absolute left-0 top-0"></div>
      <div className="w-[27px] h-[15px] flex-shrink-0 absolute left-[15px] top-[15px]">
        <svg className="w-[27px] h-[15px] flex-shrink-0 fill-[#2F33A8] absolute left-0 top-0" width="28" height="16" viewBox="0 0 28 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path 
            fillRule="evenodd" 
            clipRule="evenodd" 
            d="M6.77047 3.28338C6.47775 1.56269 4.89544 0.410809 3.24307 0.715537C2.02354 0.940465 1.10293 1.89732 0.821294 3.07484C0.820761 3.07728 0.820228 3.07973 0.819588 3.08218C0.809351 3.12538 0.799967 3.16889 0.791542 3.21262C0.790476 3.21773 0.789516 3.22295 0.78845 3.22805C0.780452 3.27061 0.7732 3.31338 0.766908 3.35648C0.766055 3.3618 0.765096 3.36712 0.764349 3.37244C0.757418 3.42042 0.751446 3.46873 0.746647 3.51725L0.745687 3.52735C0.741422 3.57108 0.738223 3.61492 0.735983 3.65876C0.735237 3.6728 0.734384 3.68685 0.73385 3.70089C0.732251 3.73547 0.731718 3.77026 0.731291 3.80516C0.731184 3.81899 0.730225 3.83261 0.730225 3.84645C0.730225 3.85836 0.730971 3.87017 0.731184 3.88209C0.731398 3.90071 0.732037 3.91922 0.732464 3.93784C0.737156 4.08701 0.751552 4.23757 0.777252 4.38887C0.944356 5.37072 1.84407 6.02572 2.78708 5.85186C3.12747 5.78898 3.42702 5.62672 3.66301 5.39871C3.85848 5.20974 4.14918 5.15824 4.39903 5.26645C4.69442 5.39424 5.02714 5.43861 5.3655 5.37615C6.27065 5.20921 6.88607 4.33918 6.78625 3.40106C6.7821 3.36201 6.77708 3.32275 6.77047 3.28338ZM14.0606 1.12465C10.7229 1.12465 8.64951 2.29855 8.64951 4.18799C8.64951 6.39078 10.7735 9.39773 14.0606 9.39773C17.2971 9.39773 19.4717 6.35695 19.4717 4.18799C19.4717 2.26983 17.4488 1.12465 14.0606 1.12465ZM27.3865 3.7009C27.386 3.68632 27.3851 3.67175 27.3844 3.65728C27.382 3.61386 27.3789 3.57067 27.3748 3.52736L27.3738 3.51725C27.369 3.46874 27.3629 3.42043 27.3561 3.37244C27.3553 3.36712 27.3543 3.3618 27.3536 3.35648C27.3472 3.31339 27.34 3.27062 27.3319 3.22806C27.3309 3.22295 27.3299 3.21774 27.3288 3.21263C27.3204 3.1689 27.311 3.12538 27.3008 3.08219C27.3002 3.07974 27.2996 3.07729 27.2991 3.07484C27.0174 1.89732 26.0968 0.940473 24.8773 0.715545C23.2249 0.410817 21.6426 1.5627 21.3499 3.28339C21.3432 3.32276 21.3383 3.36202 21.3341 3.40107C21.2342 4.33919 21.8497 5.20922 22.7549 5.37616C23.0932 5.43861 23.426 5.39425 23.7214 5.26646C23.9712 5.15836 24.2619 5.20975 24.4573 5.39871C24.6933 5.62672 24.9929 5.78898 25.3334 5.85186C26.2764 6.02572 27.1761 5.37072 27.3431 4.38887C27.3688 4.23757 27.3831 4.08701 27.3879 3.93784C27.3884 3.91922 27.3891 3.90071 27.3893 3.88209C27.3894 3.87017 27.39 3.85836 27.39 3.84645C27.39 3.83261 27.3893 3.81899 27.3891 3.80516C27.3886 3.77026 27.3881 3.73547 27.3865 3.7009ZM18.8586 11.1353C17.9822 10.7425 16.8042 11.4132 15.8089 11.5755C15.2228 11.6756 14.6423 11.7274 14.0606 11.7333C13.4788 11.7272 12.8982 11.6753 12.3121 11.5755C11.3168 11.4131 10.1389 10.7429 9.26247 11.1353C8.81811 11.3359 8.68118 11.8254 8.86172 12.4097C8.98585 12.809 9.22547 13.1778 9.53003 13.4746C10.1629 14.0948 10.9722 14.564 11.7174 14.8608C12.476 15.1652 13.2676 15.3276 14.0606 15.3334C14.8537 15.3278 15.645 15.1655 16.4038 14.8608C17.1489 14.5643 17.9582 14.0943 18.5911 13.4746C18.8954 13.1776 19.1353 12.8088 19.2594 12.4097C19.44 11.8259 19.303 11.3354 18.8586 11.1353"
            fill="#2F33A8"
          />
        </svg>
      </div>
      <div className="w-[41px] h-[14px] flex-shrink-0 absolute left-[44px] top-[15px]">
        <svg className="w-[41px] h-[14px] flex-shrink-0 fill-[#2F33A8] absolute left-0 top-0" width="43" height="16" viewBox="0 0 43 16" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path 
            fillRule="evenodd" 
            clipRule="evenodd" 
            d="M38.6247 4.6233C37.3106 4.6233 36.2947 5.09914 35.5576 6.18996V5.24315C35.5576 5.02114 35.3768 4.84118 35.154 4.84118H32.5362C32.3132 4.84118 32.1325 5.02114 32.1325 5.24315V14.7132C32.1325 14.9351 32.3132 15.1151 32.5362 15.1151H35.154C35.3768 15.1151 35.5576 14.9351 35.5576 14.7132V9.56193C35.5576 8.39166 35.9758 7.36013 37.2108 7.36013C38.4653 7.36013 38.8439 8.57018 38.8439 9.56193V14.7132C38.8439 14.9351 39.0245 15.1151 39.2475 15.1151H41.866C42.0889 15.1151 42.2696 14.9351 42.2696 14.7132V9.36338C42.2696 7.12221 41.6323 4.6233 38.6247 4.6233ZM18.349 12.6379L17.8082 12.6367C17.379 12.6219 17.1899 12.2971 17.1899 11.8582V11.6585H17.1913V1.3785C17.1913 1.15649 17.0106 0.976532 16.7876 0.976532H14.2392C14.0161 0.976532 13.8354 1.15649 13.8354 1.3785V11.6823C13.8354 14.6323 15.7382 15.3161 17.5233 15.3161C17.7688 15.3161 18.0045 15.3001 18.381 15.269C18.5901 15.2517 18.7517 15.0773 18.7517 14.8684V13.0399C18.7517 12.8182 18.5715 12.6384 18.349 12.6379ZM24.8682 12.6558C23.4147 12.6558 22.518 11.4659 22.518 9.95833C22.518 8.51047 23.3744 7.32047 24.8287 7.32047C26.2822 7.32047 27.2579 8.41129 27.2579 10.0574C27.2579 11.6838 26.2225 12.6558 24.8682 12.6558ZM30.2003 4.84118H27.5818C27.3588 4.84118 27.1782 5.02114 27.1782 5.24315V6.21001C26.5409 5.25802 25.3863 4.6233 24.0319 4.6233C21.0049 4.6233 19.0729 6.98347 19.0729 9.95833C19.0729 12.9929 21.084 15.3333 24.052 15.3333C25.5054 15.3333 26.5214 14.7183 27.1782 13.707V14.7132C27.1782 14.9351 27.3588 15.1151 27.5818 15.1151H30.2003C30.4232 15.1151 30.6039 14.9351 30.6039 14.7132V5.24315C30.6039 5.02114 30.4232 4.84118 30.2003 4.84118ZM6.57111 12.6558C5.11759 12.6558 4.22101 11.4659 4.22101 9.95833C4.22101 8.51047 5.07744 7.32047 6.53159 7.32047C7.98512 7.32047 8.96084 8.41129 8.96084 10.0574C8.96084 11.6838 7.92547 12.6558 6.57111 12.6558ZM11.9032 4.84118H9.2847C9.06177 4.84118 8.88107 5.02114 8.88107 5.24315V6.21001C8.24383 5.25802 7.08916 4.6233 5.7348 4.6233C2.70783 4.6233 0.775879 6.98347 0.775879 9.95833C0.775879 12.9929 2.78687 15.3333 5.75492 15.3333C7.20845 15.3333 8.22432 14.7183 8.88107 13.707V14.7132C8.88107 14.9351 9.06177 15.1151 9.2847 15.1151H11.9032C12.1261 15.1151 12.3068 14.9351 12.3068 14.7132V5.24315C12.3068 5.02114 12.1261 4.84118 11.9032 4.84118"
            fill="#2F33A8"
          />
        </svg>
      </div>
    </div>
  </div>
);

export default function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: ""
  });

  const handleSubmit = () => {
    // Here you would implement actual login logic
    console.log("Login with:", formData);
    // For now, just navigate to overview
    navigate("/overview");
  };

  return (
    <div className="flex min-h-screen w-full px-6 flex-col items-start gap-6 bg-gradient-to-br from-[#8C99FA] via-[#5C59F3] to-[#94C1FF] overflow-hidden">
      {/* Header with logo */}
      <div className="flex pt-2.5 flex-col items-start gap-10 self-stretch">
        <div className="flex flex-col items-start self-stretch">
          <div className="flex justify-end items-start gap-2.5 self-stretch">
            <Logo />
          </div>
          
          {/* Title */}
          <div className="self-stretch text-[#0C0A66] text-center font-montserrat text-[40px] font-normal leading-[125%] mt-10">
            <span className="font-dynapuff font-bold">Add Years of Good Life</span>
            <span className="font-montserrat font-bold"> </span>
            <span className="font-montserrat font-normal">in 30 days</span>
          </div>
        </div>
      </div>
      
      {/* Form fields and button */}
      <div className="flex flex-col items-start gap-10 w-full max-w-4xl mx-auto px-4">
        <div className="flex flex-col items-start gap-2.5 w-full">
          <FormField
            label="Email"
            placeholder="Input here"
            value={formData.email}
            onChange={(value) => setFormData({ ...formData, email: value })}
            type="email"
          />
          <FormField
            label="Password"
            placeholder="Input here"
            value={formData.password}
            onChange={(value) => setFormData({ ...formData, password: value })}
            type="password"
          />
        </div>

        {/* Log in button */}
        <div className="flex justify-center w-full">
          <button
            onClick={handleSubmit}
            className="flex p-5 items-center gap-[-16px] rounded-[20px] bg-gradient-to-b from-[#838CF8] to-[#5D58DD] cursor-pointer transition-all duration-200 hover:shadow-lg hover:scale-[1.02]"
          >
            <div className="flex flex-col justify-center items-start gap-[3px]">
              <div className="text-[#E8DEF8] font-montserrat text-[20px] font-bold leading-[125%]">
                Log in
              </div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
